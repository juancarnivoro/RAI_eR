####################################
# RAI:an R package to calculate relative abundance index from camera-traps
# Development by: SMandujanoR
# Last modification: April 27, 2022
####################################
#
# NOTE: To save the tables, graphs, statistical analysis and maps in the "Results" folder, you most to activate the function with the "#" symbol in the write.csv(), jpeg() and dev.off() functions.

####################################
# DATA PREPARATION: tengo checar bien esta función aun no trabaja bien para todos los casos
####################################

# Function to format the .csv data generated from camtrapR

###dataFormat <- function(data_Spp, data_CT, speciesCol, stationCol, setupCol, retrievalCol, CTDateFormat) {

###require(camtrapR)
###require(dplyr)
###require(fuzzySim)
  
  #-----------------------------
  # Use the function surveyReport to modified the parameters:
  
###report <- surveyReport (recordTable = data_Spp, CTtable = data_CT, speciesCol = speciesCol, stationCol = stationCol, setupCol = setupCol, retrievalCol = retrievalCol, CTDateFormat = CTDateFormat, recordDateTimeCol = "DateTimeOriginal", recordDateTimeFormat = "%Y-%m-%d %H:%M:%S", CTHasProblems = T)
  
###sampling_effort <- report[[1]]
  
###days <- sampling_effort %>%
###dplyr::select(1, 7)
  
###species <- report[[5]]
  
  #-----------------------------
  # Merge data.frame:
###wildlife.data <- merge(species, days, all.y = T)
  
  #-----------------------------
  # Rename columns:
###Station <- sampling_effort %>%
###dplyr::select(1)
###n_events <- species %>%
###dplyr::select(3)
###n_nights_active <- sampling_effort %>%
###dplyr::select(7)
  
###wildlife.data <- wildlife.data %>%
###rename(Camera = Station, Events = n_events, Effort = n_nights_active)
  
  #-----------------------------
  # Species names abbreviation:
###wildlife.data$Species <- spCodes(wildlife.data$Species, sep.spcode = "_")
  
  #-----------------------------
  # Save the formatted data:
###write.csv(wildlife.data, "data/wildlife_data.csv")
###}


####################################
# ANALYSIS OF SEVERAL SPECIES
####################################

# Classic or general RAI model (Eq.1)

  ## Function of RAI estimation:

RAIgral <- function(new.mat, Species, parRow, parCol, pointSize) {

  require(stringr)
  
  # ---------------------------------
  ## RAIgral estimation:
  
  Tot_cameras <- with(new.mat, length(unique(Camera)))
  cameras <- with(new.mat, tapply(Camera, Species, length))
  days <- with(new.mat, tapply(Effort, Species, sum))
  n <- with(new.mat, tapply(Events, Species, sum))
  RAIgral <- round(n/days*100, 2)
  
  # ---------------------------------
  ## Naive occupation estimation:
  
  occ <- subset(new.mat, new.mat$Events > 0)
  OccNaive <- as.data.frame(round(table(occ$Species)/cameras,2))
  
  # ---------------------------------
  ## Results:
  
  table1 <- cbind(cameras, days, n, RAIgral, OccNaive = OccNaive[,2])
  table1 <- table1[order(RAIgral),]
  print(table1)
  write.csv(table1, "Results/Table_RAIgral.csv")
  
  # ---------------------------------
  ## RAI-naive occupation graph:
  
  jpeg(filename = "Results/Dist_Abun.jpg", width = 7000, height = 5000, units = "px", res = 1200)
  
  r2 <- round(cor(RAIgral, OccNaive[,2]),2)
  plot(OccNaive[,2], RAIgral, xlab= "Distribution (Naive_Occ)", ylab = "Relative abundance (RAI)", main = paste("r2 =", r2), frame.plot = F, las = 1, pch = 16, col = "skyblue", cex = 2)
  abline(lm(RAIgral ~ OccNaive[,2]), col = "red", lwd = 2)
  text(OccNaive[,2], RAIgral, OccNaive[,1], cex = 0.5)
  
  dev.off()
  
  # ---------------------------------
  ## Events distribution graph:
  
  jpeg(filename = "Results/Dist_Spp.jpg", width = 7000, height = 5000, units = "px", res = 1200)
  
  par(mfcol = c(parRow, parCol), mar = c(3,1,1,1))
  
  for (i in 1:length(Species)) {
    sp  <- subset(new.mat, Species == Species[i])
    
    plot(sp$X, sp$Y, xlab = "", ylab = "", frame.plot = F, cex.axis = 1, main = unique(sp$Species), type = "n", labels = F, cex.main = 0.9)
    points(sp$X, sp$Y, pch = 16, col = "skyblue", cex = sp$Events*pointSize)
    text(sp$X, sp$Y, sp$Events, cex = 0.7)
  }
  dev.off()
}

####################################
# RAI alternative model (Eq.2)

  ## Function of RAI estimation:

RAIalt <- function(new.mat, max) {

  require(xtable)
  require(agricolae)
  require(tidyverse)
  
  RAIalt <- with(new.mat, round((Events/Effort)*100, 2))
  table2 <- cbind(new.mat, RAIalt)
  write.csv(table2, "Results/Table_RAIalt.csv")
  
  jpeg(filename = "Results/RAIalt.jpg", width = 7000, height = 5000, units = "px", res = 1200)
  
  par(mfcol = c(1,1), mar = c(5,5,5,5))
  
  boxplot(RAIalt ~ Species, data = new.mat, ylab = "RAI", ylim = c(0, max), xlab = "", varwidth = F, outline = F, cex = 3.4, las = 2, frame.plot = F, cex.axis = 0.7, col = "skyblue")
  dev.off()
  
  # ---------------------------------
  # Statistical comparison
  
  RAIaov <- aov(RAIalt ~ Species-1, data = table2)
  cat("----- \n RAI comparasion among species \n")
  mod <- summary(RAIaov)
  anova <- xtable(mod)
  write.csv(anova, "Results/Table_ANOVA.csv")
  
  # ---------------------------------
  # Posterior comparison
  
  P <- as.numeric(unlist(summary.aov(RAIaov)[[1]][5]))[1]
  
  ifelse(P < 0.05, {
    # if P significative then:
    
    ## Tukey test
    
    jpeg(filename = "Results/Tukey_test.jpg", width = 7000, height = 10000, units = "px", res = 1200)
    
    par(mfcol = c(1,1))
    
    plot(TukeyHSD(RAIaov), cex.axis = 0.5, las = 1)
    dev.off()
    
    # HSD test
    
    out_1 <- HSD.test(RAIaov, "Species")
    out2 <- out_1$groups
    
    jpeg(filename = "Results/HSD_test.jpg", width = 7000, height = 5000, units = "px", res = 1200)
    
    par(mfcol = c(1,1))
    
    bar.group(out_1$groups, horiz = F, las = 2, cex.main = 2, font = 3, cex.axis = 0.9, plot = T, col = "lightblue", ylim = c(0, max),   names.arg = out_1$trt, ylab = "RAI")
    dev.off()
    
  }, NA) # if P not significant
  
  # ---------------------------------
  # Create array of species by RAI and Events:
  
  table2 <- read.csv("Results/Table_RAIalt.csv", header = T)
  SppRAI <- table2 %>% dplyr::select(Camera, Species, RAIalt)
  SppRAI <- arrange(SppRAI, Species)
  SppRAI <- pivot_wider(SppRAI, names_from = "Species", values_from =  "RAIalt")
  write.csv(SppRAI, "Results/Table_Spp_RAI.csv")
  
  SppEvents <- table2 %>% dplyr::select(Camera, Species, Events)
  SppEvents <- arrange(SppEvents, Species)
  matSpp_Event <- pivot_wider(SppEvents, names_from = "Species", values_from =  "Events")
  write.csv(matSpp_Event, "Results/Table_Spp_Events.csv")
  
}

####################################
# RAI GLM-Poisson regression (Eq.3) with "offsets":

RAIglm <- function(new.mat, family = family) {
  
  require(xtable)
  
  RAIglm <- glm(Events ~ Species-1, data = new.mat, offset = log(Effort), family = family)
  cat("----- \n GLM-Poisson: \n")
  print(summary(RAIglm))
  modglm <- summary(RAIglm)
  
  RAIpoisson <- cbind(RAIpoisson = round(exp(RAIglm$coefficients)*100, 2))
  RAIpoisson <- RAIpoisson[order(RAIpoisson),]
  table_glm <- xtable(modglm)
  mlg <- cbind(table_glm, RAIpoisson)
  write.csv(mlg, "Results/Table_Spp_GLM.csv")
}


####################################
# Function to interpolation of RAI-NaiveOcc

RAIinterp <- function(new.mat) {
  
  require(akima)
  require(MASS)
  require(RColorBrewer)
  
  table2 <- read.csv("Results/Table_RAIalt.csv", header = T)
  
  RAImean <- with(table2, round(tapply(RAIalt, Species, mean),2))
  RAIsd <- with(table2, round(tapply(RAIalt, Species, sd),2))
  occ <- subset(table2, table2$Events > 0)
  cameras <- with(new.mat, tapply(Camera, Species, length))
  n <- with(new.mat, tapply(Events, Species, sum)) 
  OccNaive <- round(table(occ$Species)/cameras,2)
  
  g <- interp(RAImean, OccNaive, n, duplicate = T)
  
  jpeg(filename= "Results/Interpolation.jpg", width = 7000, height = 5000, units = "px", res = 1200)
  
  par(mfrow = c(1,1))
  
  image(g, col= topo.colors(12), cex.lab = 1.0, frame = F, xlab = "RAI", ylab = "Naive occupation", xlim = c(0, max(RAImean + 2)), ylim = c(0, 1.1))
  contour(g, add = T)
  text(RAImean, jitter(OccNaive,3), labels = unique(sort(table2$Species)), cex = 1, pos = 4, col = "red")
  
  dev.off()
}

####################################
# Function to create final Table

RAIfinal <- function(new.mat) {
  t1 <- read.csv("Results/Table_RAIgral.csv", header = T)
  t2 <- read.csv("Results/Table_RAIalt.csv", header = T)
  t3 <- read.csv("Results/Table_Spp_GLM.csv", header = T)
  
  RAIalt.mean <-  with(t2, round(tapply(RAIalt, Species, mean), 2))
  RAIalt.sd <- with(t2, round(tapply(RAIalt, Species, sd), 2))
  alt <- cbind(RAIalt.mean, RAIalt.sd)
  alt2 <- alt[order(RAIalt.mean),]
  
  table3 <- with(c(t1,t3), cbind(cameras, days, n, RAIgral, alt2, RAIpoisson, OccNaive))
  #print(table3)
  write.csv(table3, "Results/Table_Final.csv")
}

####################################
# ANALYSIS OF ONE SPECIES
####################################

# Function to GLM-Poisson for selected species and analysis of covariates

RAIglmSp <- function(Species, covs, family) {
  
  ## Select species:
  
  new.mat <- read.csv("Results/Table_RAIalt.csv", header = T, sep = ",")
  Sp <- new.mat[new.mat$Species== Species,]
  Sp <- Sp %>% dplyr::select(covs, Species, Events, Effort, RAIalt)
  print(Sp)
  write.csv(Sp, paste("Results/Table_", str_to_title(Species), ".csv", sep = ""))
  
  # ---------------------------------
  ## GLM model for each covariate
  
  for(i in 1:length(covs)) {
    
    RAIglm1 <- glm(Events ~ Sp[,i]-1, offset = log(Effort), family = poisson, data = Sp)
    
    cat("---------------------------- \n RAI GLM-Poisson with covariates: \n")
    print(covs[i])
    print(summary(RAIglm1))
    table_glm <- xtable(RAIglm1)
    Cov <- covs[i]
    write.csv(table_glm, paste("Results/Table_GLM_", str_to_title(Species), "-", str_to_title(Cov), ".csv", sep = ""))
    
    if(is.character(Sp[,i]) == TRUE) {
      
      jpeg(filename= paste("Results/GLM_", str_to_title(Species), "-", str_to_title(Cov), ".jpg", sep = ""), width= 7000, height= 5000, units= "px", res=1200)
      
      par(mfrow = c(1,1), mar = c(5,5,3,1))
      
      plot(RAIalt ~ as.factor(Sp[,i]), data = Sp, frame.plot = F, col = "skyblue", pch = 16, xlab = names(Sp[i]), ylab = "Relative abundance", main = unique(Species))
      dev.off()
      
    } else {
      
      jpeg(filename= paste("Results/GLM_", str_to_title(Species), "-", str_to_title(Cov), ".jpg", sep = ""), width= 7000, height= 5000, units= "px", res=1200)
      
      par(mfrow = c(1,1), mar = c(5,5,3,1))
      
      plot(RAIalt ~ as.integer(Sp[,i]), data = Sp, frame.plot = F, col = "skyblue", pch = 16, xlab = names(Sp[i]), ylab = "Relative abundance", main = unique(Species))
      dev.off()
    }
  }
}  
  
####################################
# Function to graph the RAI of selected species 

RAImapSp <- function(mapa, species, pointSize, mycolors) {

  require(stringr)
  require(prettymapr)
  
  new.mat <- read.csv("Results/Table_RAIalt.csv", header = T)
  sp  <- subset(new.mat, Species == species)
  
  jpeg(filename= paste("Results/Map_", str_to_title(species), ".jpg", sep = ""), width= 7000, height= 5000, units= "px", res=1200)
  
  par(mfrow = c(1,1), mar = c(1,1,1,1))
  
  plot(mapa, col = mycolors, fill = T, lty = 0, main = unique(sp$Species))
  addscalebar(htin = 0.05, padin = c(0.05, 0.05), pos = "bottomright")
  addnortharrow()
  
  points(sp$X, sp$Y, pch = 16, col = "#00000170", cex = sp$RAIalt*pointSize)
  text(sp$X, sp$Y, sp$RAIalt, cex = 0.3)
  
  dev.off()
}


####################################
# Function to kernel utilization distribution for selected species

RAIkernelSp <- function(species, S, HR, pointSize, proje, mycolors) {

  require(stringr)
  require(prettymapr)
  require(raster)
  require(prettymapr)
  require(adehabitatHR)
  require(dplyr)
  require(tidyverse)

  # ----------------------------
  # Read RAIalt table:
  new.mat <- read.csv("Results/Table_RAIalt.csv", header = T)
  new.mat  <- subset(new.mat, Species == species)
  sp <- dplyr::select(new.mat, c("X", "Y", "Events"))
  
  # ----------------------
  # Preparation of data:
  
  n <- length(sp$Events)
  nueva_mat <- vector("numeric", n)
  
  repetir <- function(i) {
    do.call("rbind", replicate(sp$Events[i], sp[i,], simplify = F))
  }
  
  for (i in 1:n) {
    nuevo <- repetir(i)
    nueva_mat <- rbind(nueva_mat, nuevo)
  }
  
  nueva_mat
  (species_coord <- nueva_mat[-1,-3])
  
  presenciaSP <- SpatialPoints(coords = species_coord)
  projection(presenciaSP) <- proj
  
  # ----------------------
  # Kernel analysis using adehabitatHR package 
  
  S <- S # Extent
  HR <- HR # Home range
  
  (speciesUD <- kernelUD(presenciaSP, h = "href", kern = "bivnorm", grid = 95, hlim = c(0.75, 0.75), extent = S))
  (speciesHR <- getverticeshr(speciesUD, percent = HR))
  
  jpeg(filename= paste("Results/Kernel_", str_to_title(species), ".jpg", sep = ""), width= 8000, height= 7000, units= "px", res=1200)
  
  par(mfrow = c(1,1), mar = c(1,1,1,1))
  
  mi_mapaL <- as(mi_mapa, "SpatialLinesDataFrame")
  mi_mapaL <- spTransform(mi_mapaL, proje)
  
  image(speciesUD, col = mycolors, interpolate = F, cex.main = 1, main = paste("\n \n Species =", unique(new.mat$Species), "\n Utilization distribution of ", HR, "% = ", round(speciesHR$area, 1), "ha"), cex.main = 1.2)
  
  plot(mi_mapaL, add = T, col = "gray")
  points(sp$X, sp$Y, pch = 16, col = rgb(1, 0, 0, 0.75), cex = sp$RAIalt/pointSize)
  plot(speciesHR, add = T)
  addscalebar(htin = 0.05, padin = c(0.05, 0.05), pos = "bottomright")
  addnortharrow()
  
  dev.off()
  
  # ------------------
  # Create a Raster layer:
  
  Kernel_capa <- cbind(speciesUD@coords, speciesUD@data)
  kernel_data <- as.data.frame(Kernel_capa)
  coordinates(kernel_data) <- ~Var2 + Var1
  r <- raster(ncol = 60, nrow = 30)
  extent(r) <- extent(mi_mapaL)
  vals <- kernel_data$ud
  kernel_rast <- rasterize(kernel_data, r, vals)
  
  jpeg(filename = paste("Results/KernelRaster_", str_to_title(species), ".jpg", sep = ""), width= 8000, height= 7000, units= "px", res=1200)
  
  plot(kernel_rast)
  
  dev.off()
  
  writeRaster(kernel_rast, paste("Results/KernelRaster_", str_to_title(species), ".tiff", sep = ""), overwrite = T)
}


####################################
# Function to create a camera-trap grid

mi_Grid <- function(n1, n2, CTx, CTy, CTdist) {
  
  require(raster)
  require(prettymapr)
  
  # -------------------
  # To create grid:
  
  jpeg(filename = "Results/CT_grid.jpg", width = 8000, height = 7000, units = "px", res = 1200)
  
  par(mfrow = c(1,1), mar = c(1,1,1,1))
  
  plot(mi_mapa, col = mi_paleta, fill = T, lty = 0)
  addscalebar(htin = 0.05, padin = c(0.05, 0.05), pos = "bottomright")
  addnortharrow()
  
  # -------------------
  # To create the grid:
  
  x <- seq(from = CTx, to = (CTx + n1*CTdist-CTdist), by = CTdist)
  y <- seq(from = CTy, to = (CTy + n2*CTdist-CTdist), by = CTdist)
  xy <- expand.grid(x = x, y = y)
  points(xy, col = "black", pch = 16, cex = 1.5)
  n <- as.character(1:(n1*n2))
  text(xy, n, col = "white", cex = 0.5)
  cat("-------- \n UTMs \n")
  print(xy)
  write.csv(xy, "Results/UTMs_grid.csv")
  
  # -------------------
  # To create buffer around the gris:
  
  xySP <- SpatialPoints(coords = xy)
  projection(xySP) <- "+proj=utm +zone=14 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0"
  class(xySP)
  bbox(xySP)
  xSP <- seq(from = bbox(xySP)[1]-CTdist, to = bbox(xySP)[3]+CTdist, by = n1*CTdist+CTdist)
  ySP <- seq(from = bbox(xySP)[2]-CTdist, to = bbox(xySP)[4]+CTdist, by = n2*CTdist+CTdist)
  xy2 <- expand.grid(x = xSP, y = ySP)
  points(xy2, col = "black", bg = "red", pch = 22, cex = 1)
  buf <- rbind(xy2[1,], xy2[2,], xy2[4,], xy2[3,], xy2[1,])
  lines(buf, add = T, col = "red", lty = 1, lwd = 3)
  
  # -------------------
  # To estimate area:
  
  cat("---------- \n Grid hectares = \n ") 
  print(S_grid1 <- (((n1-1)*CTdist) * ((n2-1)*CTdist))/10000)
  
  cat("------------- \n Grid + buffer = \n ")
  print(S_grid2 <- (((n1+1)*CTdist) * ((n2+1)*CTdist))/10000)
  
  legend("bottomleft", c(paste("Grid of ", (n1*n2), "camera-traps,", "at", CTdist, "meters,"), paste("Grid area = ", S_grid1, "hectares,"), paste("and grid + buffer =", S_grid2, "hectares (red quadrant).")), cex = 0.8)
  
  dev.off()
}

############################
# END SCRIPT
