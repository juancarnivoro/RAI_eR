################################
# RAI: an R package to calculate relative abundance index from camera-traps
# Author: SMandujanoR
# Last modification: April 26, 2022 
################################

# Leer el paquete:

source("code/RAI.R")

# ----
# Esto se hace solo la primera vez

dir.create("Results")

# ----
# Leer datos de los animales

wildlife_data <- read.csv("data/mamiferos.csv", header = T)
View(wildlife_data)
names(wildlife_data)
unique(wildlife_data$Species)

# Leer datos de covariables 
habitat_data <- read.csv("data/habitat.csv", header = T)
View(habitat_data)

# Pegar ambas data.frames

datos <- merge(x = wildlife_data, y = habitat_data, by = "Camera", all = TRUE)
head(datos, 15)

# ----
# Se corre cada función por separado y los resultados en forma de figuras y tablas, aparecen en la carpeta recién creada "Results"

RAIgral(datos, c("Syl_flo", "Odo_vir", "Can_lat", "Uro_cin", "Spi_put", "Bas_ast"), parRow = 2, parCol = 3, pointSize = 0.3)

RAIalt(datos, max = 30) 

RAIglm(datos, family = "poisson") 

RAIfinal(datos)

RAIinterp(datos)

# ------------
# GLM para especies seleccionada y covariables:

RAIglmSp(Species = "Syl_flo", covs = c("Veg_type", "Loc_dist", "scrub", "Goats"), family = "poisson")

# ------------------
# Para crear diferentes mapas

library(raster)

# leer el shapefile del mapa
mi_mapa <- shapefile("data/veg.shp")

# Importante, para cada caso específico esto se modifica de acuerdo a la zona del sitio de estudio
mi_mapa <- spTransform(mi_mapa, "+proj=utm +zone=14 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0")
class(mi_mapa)
mi_mapa$tipo_Suelo

# esta paleta de colores la debe modificar cada usuario en función del número de tipos de coberturas en su mapa, y preferencias personales
mi_paleta <- c("gold", "deepskyblue2", "darkolivegreen4", "darkolivegreen1", "azure3", "darkorange2")

plot(mi_mapa)

# -----
# se crean varios mapas (ver carpeta "Results") para cada especie seleccionada

RAImapSp(map = mi_mapa, species = "Odo_vir", pointSize = 0.1, mycolors = mi_paleta)

RAIkernelSp("Uro_cin", S = 0.9, HR = 95, pointSize =  20, proje = "+proj=utm +zone=14 +datum=WGS84 +units=m +no_defs +ellps=WGS84 +towgs84=0,0,0", mycolors = hcl.colors(99, palette = "viridis", alpha = NULL, rev = F))  

# ----------
# esta es una función extra para definir posible diseño de muestreo en forma de grid con número de cámaras y separación entre éstas de acuerdo al usuario. Se definen las coordenadas UTM de la cámara inicial para el Grid, y en la carpeta "Results" aparece la tabla de UTMs para cada cámara, lo cual luego se puede cargar a un GPS para ubicar en campo

mi_Grid(n1 = 7, n2 = 6, CTx = 690500, CTy = 2007000, CTdist = 800)

# ---------------------
# FIN SCRIPT

rm(list = ls()) # limpiar memoria
dev.off() # limpiar gráficos

